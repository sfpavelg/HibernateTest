create view employeessalary(id, name, surname, department, salary) as
SELECT employees.id,
       employees.name,
       employees.surname,
       employees.department,
       employees.salary
FROM employees
WHERE employees.salary > '2000'::numeric;

alter table employeessalary
    owner to postgres;

