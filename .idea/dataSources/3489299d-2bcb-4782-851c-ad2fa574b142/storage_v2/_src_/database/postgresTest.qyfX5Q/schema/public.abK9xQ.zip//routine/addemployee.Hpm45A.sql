create procedure addemployee(IN employee_name character varying, IN employee_surname character varying, IN employee_department character varying, IN employee_salary numeric)
    language plpgsql
as
$$ BEGIN INSERT INTO employees(name, surname, department, salary) VALUES(employee_name, employee_surname, employee_department, employee_salary); END; $$;

alter procedure addemployee(varchar, varchar, varchar, numeric) owner to postgres;

